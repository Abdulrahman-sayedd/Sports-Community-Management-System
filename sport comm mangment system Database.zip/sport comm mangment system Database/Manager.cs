﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sport_comm_database
{
    public partial class Manager : Form
    {
        public Manager()
        {
            InitializeComponent();
        }
        void BindData()
        {
            SqlCommand cmd = new SqlCommand("Select * From manager ", con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=\"sports community\";Integrated Security=True;Encrypt=False");
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void ADD_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Insert into manager values ('" + int.Parse(textBox1.Text) + "','" + textBox3.Text + "')", con);
            command.ExecuteNonQuery();
            BindData();
            MessageBox.Show("100/100", "Succsess", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"AN error occurred:{ex.Message}");
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {
            con.Open();
            SqlCommand command = new SqlCommand("Delete manager where manager_id='"+int.Parse(textBox1.Text) +"'",con);
            command.ExecuteNonQuery();
            MessageBox.Show("Deleted Succsessfully", "Succsessfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
            BindData();
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"AN error occurred:{ex.Message}");
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Update manager set manager_name='" + int.Parse(textBox3.Text) + "' Where manager_id='" + int.Parse(textBox1.Text) + "' ", con);
            command.ExecuteNonQuery();
            MessageBox.Show("Updated succsessfully", "Sucssesfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
            BindData();
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"AN error occurred:{ex.Message}");
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try { 
            
            SqlCommand cmd = new SqlCommand("Select * From manager WHERE manager_id='" + int.Parse(textBox1.Text) + "' ", con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"AN error occurred:{ex.Message}");
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Manager_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sports_communityDataSet5.manager' table. You can move, or remove it, as needed.
            this.managerTableAdapter.Fill(this.sports_communityDataSet5.manager);

        }
    }
}
