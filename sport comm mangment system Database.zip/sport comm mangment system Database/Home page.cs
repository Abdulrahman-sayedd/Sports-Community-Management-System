﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sport_comm_database
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ADD_Click(object sender, EventArgs e)
        {


        }
   

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
         
        }

        private void Delete_Click(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FootballFeild f2 = new FootballFeild();
            f2.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Manager m = new Manager();
            m.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            BasketBallFeild b2 = new BasketBallFeild();
            b2.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Membership m = new Membership();
            m.Show();

        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            Player p=new Player();
            p.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Reservation r = new Reservation();
            r.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Coach c = new Coach();  
            c.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            clinics c= new clinics();
            c.Show();
        }
    }
}
