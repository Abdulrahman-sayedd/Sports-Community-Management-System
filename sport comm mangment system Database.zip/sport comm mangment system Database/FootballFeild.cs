﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sport_comm_database
{
    public partial class FootballFeild : Form
    {
        public FootballFeild()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }


        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=\"sports community\";Integrated Security=True;Encrypt=False");
     
        private void ADD_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Insert into Football_Feild values('"+int.Parse(textBox1.Text) +"','"+int.Parse(textBox3.Text) + "','"+int.Parse(textBox4.Text) + "','"+int.Parse(textBox2.Text) +"')", con);
            command.ExecuteNonQuery();
            MessageBox.Show("bravo 3leek");
            BindData();
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"An error occurred:{ex.Message}");
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

       void BindData ()
        {
            SqlCommand cmd = new SqlCommand("select * from Football_Feild", con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Delete  Football_Feild where Feild_id='"+ int .Parse(textBox1.Text) +"'",con);
            command.ExecuteNonQuery();
            MessageBox.Show("bravo 3leek ","succsess",MessageBoxButtons.OK,MessageBoxIcon.Information);
            BindData();
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"An error occurred:{ex.Message}");
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Update Football_Feild set Hour_rate='" + int.Parse(textBox3.Text) + "', avaliable_hours='" + int.Parse(textBox4.Text) +  "',manager_id='"+int.Parse(textBox2.Text) +"' where Feild_id='"+int.Parse(textBox1.Text) +"'", con);
            command.ExecuteNonQuery();
            MessageBox.Show("Waddy");
            BindData();
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"An error occurred:{ex.Message}");
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try { 
            SqlCommand cmd = new SqlCommand("Select * from Football_Feild where Feild_id='"+int.Parse(textBox1.Text) +"' ",con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt=new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"An error occurred:{ex.Message}");
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void FootballFeild_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sports_communityDataSet2.Football_Feild' table. You can move, or remove it, as needed.
            this.football_FeildTableAdapter.Fill(this.sports_communityDataSet2.Football_Feild);

        }
    }
}
