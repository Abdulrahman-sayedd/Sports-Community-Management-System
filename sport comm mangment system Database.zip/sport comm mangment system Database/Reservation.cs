﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace sport_comm_database
{
    public partial class Reservation : Form
    {
        public Reservation()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=\"sports community\";Integrated Security=True;Encrypt=False");
        void BindData()
        {
            SqlCommand cmd = new SqlCommand("Select * From Reservation ", con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("Insert into Reservation values ('" + int.Parse(textBox5.Text) + "','" + int.Parse(textBox1.Text) + "','" + int.Parse(textBox2.Text) + "','" + DateTime.Parse(dateTimePicker1.Text) + "','" + int.Parse(textBox4.Text) + "','" + int.Parse(textBox3.Text) + "','" + int.Parse(textBox6.Text) + "','" + comboBox1.Text + "')", con);
                command.ExecuteNonQuery();
                BindData();
                MessageBox.Show("100/100", "Succsess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"An error occurred:{ex.Message}");
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("Delete Reservation where Reservation_id='" + int.Parse(textBox5.Text) + "'", con);
                command.ExecuteNonQuery();
                MessageBox.Show("Deleted Succsessfully", "Succsessfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindData();
                con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("Update Reservation set Feild_id='" + int.Parse(textBox1.Text) + "',C_id='" + int.Parse(textBox2.Text) + "',reservation_date='" + DateTime.Parse(dateTimePicker1.Text) + "',player_id='" + int.Parse(textBox4.Text) + "',clinic_id='" + int.Parse(textBox3.Text) + "',Doctor_id='" + int.Parse(textBox6.Text) + "',Feild_type='" + comboBox1.Text + "' where Reservation_id='" + int.Parse(textBox5.Text) + "'", con);
                command.ExecuteNonQuery();
                MessageBox.Show("Updated succsessfully", "Sucssesfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindData();
                con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Select * From Reservation WHERE reservation_id='" + int.Parse(textBox5.Text) + "' ", con);
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
    }
}
