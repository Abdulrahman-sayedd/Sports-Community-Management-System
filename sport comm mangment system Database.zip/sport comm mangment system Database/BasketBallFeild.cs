﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sport_comm_database
{
    public partial class BasketBallFeild : Form
    {
        public BasketBallFeild()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=\"sports community\";Integrated Security=True;Encrypt=False");
        private void ADD_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Insert into Basketball_feild values ('" + int.Parse(textBox1.Text) + "','" + int.Parse(textBox3.Text) + "','" + int.Parse(textBox4.Text) + "','" + int.Parse(textBox2.Text) + "')", con);
            command.ExecuteNonQuery();
            BindData();
            MessageBox.Show("100/100", "Succsess", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }
        void BindData()
        {
            SqlCommand cmd = new SqlCommand("Select * From Basketball_feild ",con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Delete Basketball_feild where Feild_id='"+int.Parse(textBox1.Text) +"'", con);
            command.ExecuteNonQuery();
            MessageBox.Show("Deleted Succsessfully", "Succsessfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
            BindData();
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Update Basketball_feild set Hour_rate='"+ int.Parse(textBox3.Text) + "',avaliable_hours='"+ int.Parse(textBox4.Text) + "',manager_id='"+ int.Parse(textBox2.Text) + "' Where Feild_id='"+ int.Parse(textBox1.Text) + "' ",con);
            command.ExecuteNonQuery();
            MessageBox.Show("Updated succsessfully","Sucssesfull",MessageBoxButtons.OK,MessageBoxIcon.Information);
            BindData(); 
            con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try { 
            SqlCommand cmd = new SqlCommand("Select * From Basketball_feild WHERE Feild_id='"+ int.Parse(textBox1.Text) + "' ", con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void BasketBallFeild_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sports_communityDataSet3.BasketBall_feild' table. You can move, or remove it, as needed.
            this.basketBall_feildTableAdapter.Fill(this.sports_communityDataSet3.BasketBall_feild);

        }
    }
}
