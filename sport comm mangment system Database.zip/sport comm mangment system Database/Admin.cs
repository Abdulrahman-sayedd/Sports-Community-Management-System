﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sport_comm_database
{
    public partial class Admin : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=\"sports community\";Integrated Security=True;Encrypt=False");
        void BindData()
        {
            SqlCommand cmd = new SqlCommand("Select * From admin ", con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        public Admin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("Insert into admin values ('" + int.Parse(textBox1.Text) + "','" + decimal.Parse(textBox4.Text) + "','" + int.Parse(textBox2.Text) + "','" + int.Parse(textBox3.Text) + "')", con);
                command.ExecuteNonQuery();
                BindData();
                MessageBox.Show("100/100", "Succsess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
            }
            catch(Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"An error occurred:{ex.Message}");
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try { 
            con.Open();
            SqlCommand command = new SqlCommand("Delete admin where admin_id='" + int.Parse(textBox1.Text) + "'", con);
            command.ExecuteNonQuery();
            MessageBox.Show("Deleted Succsessfully", "Succsessfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
            BindData();
            con.Close();
            }
            catch(Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try {
                con.Open();
                SqlCommand command = new SqlCommand("Update admin set salary='" + decimal.Parse(textBox4.Text) + "',working_hors='" + int.Parse(textBox2.Text) + "',age='" + int.Parse(textBox3.Text) + "' where admin_id='" + int.Parse(textBox1.Text) + "'", con);
                command.ExecuteNonQuery();
                MessageBox.Show("Updated succsessfully", "Sucssesfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindData();
                con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try { 
            SqlCommand cmd = new SqlCommand("Select * From admin WHERE admin_id='" + int.Parse(textBox1.Text) + "' ", con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
            }
            catch(Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if(con.State == System.Data.ConnectionState.Open)
                { 
                    con.Close();
                }
            }
        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }
    }
}
