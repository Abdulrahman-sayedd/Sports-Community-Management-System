﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sport_comm_database
{
    public partial class clinics : Form
    {
        public clinics()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=\"sports community\";Integrated Security=True;Encrypt=False");
        void BindData()
        {
            SqlCommand cmd = new SqlCommand("Select * From clinics ", con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("Insert into clinics values ('" + int.Parse(textBox5.Text) + "','" + int.Parse(textBox1.Text) + "','" + textBox2.Text + "','" + int.Parse(textBox4.Text) + "')", con);
                command.ExecuteNonQuery();
                BindData();
                MessageBox.Show("100/100", "Succsess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"An error occurred:{ex.Message}");
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void clinics_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sports_communityDataSet4.clinics' table. You can move, or remove it, as needed.
            this.clinicsTableAdapter.Fill(this.sports_communityDataSet4.clinics);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("Delete clinics where clinic_id='" + int.Parse(textBox5.Text) + "'", con);
                command.ExecuteNonQuery();
                MessageBox.Show("Deleted Succsessfully", "Succsessfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindData();
                con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("Update clinics set doctor_id='" + int.Parse(textBox1.Text) + "',doctor_name='" + textBox2.Text + "',contact_number='" + int.Parse(textBox4.Text) + "' where Clinic_id='" + int.Parse(textBox5.Text) + "'", con);
                command.ExecuteNonQuery();
                MessageBox.Show("Updated succsessfully", "Sucssesfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindData();
                con.Close();
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"AN error occurred:{ex.Message}");
                MessageBox.Show($"an error occured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            try
            {
                SqlCommand cmd = new SqlCommand("Select * From clinics WHERE Clinic_id='" + int.Parse(textBox5.Text) + "' ", con);
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                // handle the expectation (log, display an error message ,etc
                Console.WriteLine($"AN error occurred:{ex.Message}");
                MessageBox.Show($"An Error Ocured:{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //close the connection regardless of whether an expection occured or not
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
    }
}
